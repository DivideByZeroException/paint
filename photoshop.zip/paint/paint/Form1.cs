

using System.Drawing.Drawing2D;

namespace paint
{
    public partial class Form1 : Form
    {
        Graphics figurs;
        Graphics paper;
        Figires figurs_list = new Figires();
        public Form1()
        {
            InitializeComponent();
            figurs = figures.CreateGraphics();
            paper = paper_panel.CreateGraphics();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        


        bool isHold = false;
        int thick_size = 1;
        string selected_figure = "LINE";
        int x1;
        int y1;
        int x2;
        int y2;
        private void paper_panel_MouseDown(object sender, MouseEventArgs e)
        {
            isHold = true;
            x1 = e.X;
            y1 = e.Y;
        }
        Point[] p = new Point[3] { new Point(-1, -1), new Point(-1, -1), new Point(-1, -1) };
        private void paper_panel_MouseUp(object sender, MouseEventArgs e)
        {
            isHold =false;
            x2 = e.X;
            y2 = e.Y;
            
            switch (selected_figure)
            {
                case "LINE":
                    figurs_list.Add(new Line(x1, y1, x2, y2, thick_size, color.BackColor.ToArgb().ToString()));

                    p = new Point[3] { new Point(-1, -1), new Point(-1, -1), new Point(-1, -1) };
                    break;
                case "CIRCLE":
                    figurs_list.Add(new Circle(x1, y1, x2 - x1, y2 - y1, thick_size, color.BackColor.ToArgb().ToString()));
                    break;
                    p = new Point[3] { new Point(-1, -1), new Point(-1, -1), new Point(-1, -1) };
                case "TRIANGLE":
                    
                    if (p[0].X ==-1 )
                    {
                        p[0] = new Point(x1,y1);
                        

                    }
                    else if (p[1].X ==-1)
                    {
                        p[1] = new Point(x1, y1);
                        
                    }
                    else if (p[2].X ==-1)
                    {
                        p[2] = new Point(x1, y1);
                        paper.DrawPolygon(new Pen(color.BackColor, thick_size), p);
                        figurs_list.Add(new Triangle(  p[0].X, p[0].Y, p[1].X, p[1].Y, p[2].X, p[2].Y, thick_size, color.BackColor.ToArgb().ToString()));
                       
                        
                        p = new Point[3] { new Point(-1, -1), new Point(-1, -1), new Point(-1, -1) };
                    }
                    







                    break;
                case "RECTANGLE":
                    figurs_list.Add(new Rectangle(x1, y1, x2-x1, y2-y1, thick_size, color.BackColor.ToArgb().ToString()));
                   
                    p = new Point[3] { new Point(-1, -1), new Point(-1, -1), new Point(-1, -1) };
                    break;

            }
            figurs_list.Save("eu.txt");
        }

        private void paper_panel_MouseMove(object sender, MouseEventArgs e)
        {
            if (!isHold) { return; }
            else
            {
                x2 = e.X;
                y2 = e.Y;
                if (figure.Value != 2)
                {
                    paper_panel.Invalidate();
                }

            }
        }

        private void color_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            color.BackColor = colorDialog1.Color;
        }

        private void thick_ValueChanged(object sender, EventArgs e)
        {
            thick_size = thick.Value;
        }
        

        private void ArtApp_Paint(object sender, PaintEventArgs e)
        {
            var PenF = new Pen(Color.Black, 2);
            figurs.DrawLine(PenF, 1, 7, 15, 21);
            figurs.DrawEllipse(PenF, 0, 35, 15, 15);
            figurs.DrawPolygon(PenF, new Point[3] { new Point(0, 75), new Point(7, 65), new Point(14, 75) });
            figurs.DrawPolygon(PenF, new Point[4] { new Point(1, 92), new Point(1, 110), new Point(15, 110), new Point(15, 92) });
        }

        private void paper_panel_Paint(object sender, PaintEventArgs e)
        {
            foreach (Figure f in figurs_list.getList())
            {
                f.Draw(paper);
            }
            if (figure.Value == 4)
            {
                paper.DrawLine(new Pen(color.BackColor, thick_size), x1, y1, x2, y2);
            }
            else if (figure.Value == 3)
            {
                paper.DrawEllipse(new Pen(color.BackColor, thick_size), x1, y1, x2 - x1, y2 - y1);
            }
            
            else if (figure.Value == 1)
            {
                paper.DrawRectangle(new Pen(color.BackColor, thick_size), x1, y1, x2 - x1, y2 - y1);
            }


        }


        

        private void save_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            
                
            
            saveFileDialog1.ShowDialog();
            string filename = saveFileDialog1.FileName;
            // ��������� ����� � ����
            
            
            System.IO.File.WriteAllText(filename, System.IO.File.ReadAllText("eu.txt")) ; 

        }

        private void load_Click(object sender, EventArgs e)
        {
            
            openFileDialog1.ShowDialog();
            string filename = openFileDialog1.FileName;
           
            
                figurs_list = new Figires();
                paper.Clear(Color.White);
                StreamWriter sr = new StreamWriter("eu.txt", false);
                sr.WriteLine("");
                sr.Close();
                figurs_list.Load(filename);
                figurs_list.Draw(paper);
            
            
        }

        private void clear_Click(object sender, EventArgs e)
        {
            figurs_list = new Figires();
            paper.Clear(Color.White);
            StreamWriter sr = new StreamWriter("eu.txt", false);
            sr.WriteLine("");
            sr.Close();
        }

        private void figure_ValueChanged_1(object sender, EventArgs e)
        {
            selected_figure = figure.Value.
                ToString();
            if (figure.Value == 4) { selected_figure = "LINE"; }
            else if (figure.Value == 3) { selected_figure = "CIRCLE"; }
            else if (figure.Value == 2) { selected_figure = "TRIANGLE"; }
            else if (figure.Value == 1) { selected_figure = "RECTANGLE"; }

        }
    }
}