﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace paint
{
    class Circle : Figure
    {
        public PointFig A
        {
            get { return basePointFig; }
            set { basePointFig = value; }
        }
        public PointFig B;



        public Circle(PointFig a, PointFig b) : base(a)
        {
            B = b;
        }

        public Circle(int x1, int y1, int x2, int y2, int thick, string col) : base(x1, y1)
        {
            B = new PointFig(x2, y2);
            thick_size = thick;
            fcolor = col;

        }

        public override void Draw(Graphics paper)
        {

            paper.DrawEllipse(new Pen(Color.FromArgb(int.Parse(fcolor)), thick_size), A.X, A.Y, B.X, B.Y);
            Console.WriteLine($"Круг {basePointFig}");
        }

        public override string ToString()
        {

            return $"Circle {A.X} {A.Y} {B.X} {B.Y} {thick_size} {fcolor}\n";
        }

    }
}
