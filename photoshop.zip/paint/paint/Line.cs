﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace paint
{
    class Line : Figure
    {
        public PointFig A
        {
            get { return basePointFig; }
            set { basePointFig = value; }
        }
        public PointFig B;



        public Line(PointFig a, PointFig b) : base(a)
        {
            B = b;
        }

        public Line(int x1, int y1, int x2, int y2, int thick, string col) : base(x1, y1)
        {
            B = new PointFig(x2, y2);
            thick_size = thick;
            fcolor = col;

        }

        public override void Draw(Graphics paper)
        {
            paper.DrawLine(new Pen(Color.FromArgb(int.Parse(fcolor)), thick_size), new Point(A.X, A.Y), new Point(B.X, B.Y));
            Console.WriteLine($"Линия  {A} -> {B}");
        }

        public override string ToString()
        {
            return $"Line {A.X} {A.Y} {B.X} {B.Y} {thick_size} {fcolor}\n";
        }
    }
}
