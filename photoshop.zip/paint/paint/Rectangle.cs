﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace paint
{
    class Rectangle : Figure
    {
        public int Height;
        public int Width;
        int X;
        int Y;

        public Rectangle(PointFig PointFig, int height, int width) : base(PointFig)
        {
            Height = height;
            Width = width;
        }

        public Rectangle(int x, int y, int height, int width, int thick, string col) : base(x, y)
        {
            X= x;
            Y = y;
            Height = height;
            Width = width;
            fcolor = col;
            thick_size = thick;
        }

        public override void Draw(Graphics paper)
        {

            paper.DrawRectangle(new Pen(Color.FromArgb(int.Parse(fcolor)), thick_size), X, Y, Height,Width);
        }

        public override string ToString()
        {
            return $"Rectangle {X} {Y} {Height} {Width} {thick_size} {fcolor}\n";
        }
    }
}
