﻿namespace paint
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paper_panel = new System.Windows.Forms.Panel();
            this.figures = new System.Windows.Forms.Panel();
            this.color_text = new System.Windows.Forms.Label();
            this.color = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.thick = new System.Windows.Forms.TrackBar();
            this.figure = new System.Windows.Forms.TrackBar();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.save = new System.Windows.Forms.Button();
            this.load = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.clear = new System.Windows.Forms.Button();
            this.thick_text = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.thick)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.figure)).BeginInit();
            this.SuspendLayout();
            // 
            // paper_panel
            // 
            this.paper_panel.BackColor = System.Drawing.Color.White;
            this.paper_panel.Location = new System.Drawing.Point(0, 1);
            this.paper_panel.Name = "paper_panel";
            this.paper_panel.Size = new System.Drawing.Size(1126, 600);
            this.paper_panel.TabIndex = 0;
            this.paper_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.paper_panel_Paint);
            this.paper_panel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.paper_panel_MouseDown);
            this.paper_panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.paper_panel_MouseMove);
            this.paper_panel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.paper_panel_MouseUp);
            // 
            // figures
            // 
            this.figures.Location = new System.Drawing.Point(1253, 346);
            this.figures.Name = "figures";
            this.figures.Size = new System.Drawing.Size(33, 121);
            this.figures.TabIndex = 1;
            // 
            // color_text
            // 
            this.color_text.AutoSize = true;
            this.color_text.Location = new System.Drawing.Point(1205, 43);
            this.color_text.Name = "color_text";
            this.color_text.Size = new System.Drawing.Size(81, 15);
            this.color_text.TabIndex = 2;
            this.color_text.Text = "Выбрать цвет";
            // 
            // color
            // 
            this.color.BackColor = System.Drawing.Color.Black;
            this.color.Location = new System.Drawing.Point(1205, 74);
            this.color.Name = "color";
            this.color.Size = new System.Drawing.Size(81, 34);
            this.color.TabIndex = 3;
            this.color.UseVisualStyleBackColor = false;
            this.color.Click += new System.EventHandler(this.color_Click);
            // 
            // thick
            // 
            this.thick.LargeChange = 1;
            this.thick.Location = new System.Drawing.Point(1154, 212);
            this.thick.Maximum = 50;
            this.thick.Minimum = 1;
            this.thick.Name = "thick";
            this.thick.Size = new System.Drawing.Size(181, 45);
            this.thick.TabIndex = 4;
            this.thick.Value = 1;
            this.thick.ValueChanged += new System.EventHandler(this.thick_ValueChanged);
            // 
            // figure
            // 
            this.figure.LargeChange = 1;
            this.figure.Location = new System.Drawing.Point(1202, 346);
            this.figure.Maximum = 4;
            this.figure.Minimum = 1;
            this.figure.Name = "figure";
            this.figure.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.figure.Size = new System.Drawing.Size(45, 121);
            this.figure.TabIndex = 5;
            this.figure.Value = 4;
            this.figure.ValueChanged += new System.EventHandler(this.figure_ValueChanged_1);
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(1154, 473);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(98, 30);
            this.save.TabIndex = 6;
            this.save.Text = "Сохранить";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // load
            // 
            this.load.Location = new System.Drawing.Point(1253, 473);
            this.load.Name = "load";
            this.load.Size = new System.Drawing.Size(98, 30);
            this.load.TabIndex = 7;
            this.load.Text = "Загрузить";
            this.load.UseVisualStyleBackColor = true;
            this.load.Click += new System.EventHandler(this.load_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(1202, 540);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(98, 23);
            this.clear.TabIndex = 8;
            this.clear.Text = "Очистить";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // thick_text
            // 
            this.thick_text.AutoSize = true;
            this.thick_text.Location = new System.Drawing.Point(1193, 181);
            this.thick_text.Name = "thick_text";
            this.thick_text.Size = new System.Drawing.Size(107, 15);
            this.thick_text.TabIndex = 9;
            this.thick_text.Text = "Выбрать толщину";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1368, 600);
            this.Controls.Add(this.thick_text);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.load);
            this.Controls.Add(this.save);
            this.Controls.Add(this.figure);
            this.Controls.Add(this.thick);
            this.Controls.Add(this.color);
            this.Controls.Add(this.color_text);
            this.Controls.Add(this.figures);
            this.Controls.Add(this.paper_panel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.ArtApp_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.thick)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.figure)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel paper_panel;
        private Panel figures;
        private Label color_text;
        private Button color;
        private ColorDialog colorDialog1;
        private TrackBar thick;
        private TrackBar figure;
        private SaveFileDialog saveFileDialog1;
        private Button save;
        private Button load;
        private OpenFileDialog openFileDialog1;
        private Button clear;
        private Label thick_text;
    }
}