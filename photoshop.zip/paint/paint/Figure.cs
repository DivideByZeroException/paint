﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace paint
{
   
    class Figure
    {
        protected PointFig basePointFig;
        protected int thick_size;
        protected string fcolor;

        public Figure(PointFig PointFig)
        {
            basePointFig = PointFig;
        }

        public Figure(int x = 0, int y = 0)
        {
            basePointFig = new PointFig(x, y);
        }

        public virtual void Draw(Graphics paper)
        { }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
