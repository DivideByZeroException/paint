﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace paint
{
    struct PointFig
    {
            public int X;
    public int Y;

    public PointFig(int x, int y)
    {
        X = x;
        Y = y;
    }

    public override string ToString()
    {
        return $"({X}, {Y})";
    }
}
class Figires
    {
        List<Figure> canvas;
        public List<Figure> getList()
        {
            return canvas;
        }
        public Figires()
        {
            canvas = new List<Figure>();
        }

        public void Add(Figure newFigure)
        {
            canvas.Add(newFigure);
        }

        public void Save(string path)
        {
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(path, false);
                foreach (var i in canvas)
                {
                    sw.Write(i.ToString());
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (sw != null)
                {
                    sw.Close();
                }
            }
        }

        public void Draw(Graphics paper)
        {
            foreach (var i in canvas)
            {
                i.Draw(paper);
            }
        }

        public void Load(string path)
        {
            StreamReader sw = null;
            try
            {
                sw = new StreamReader(path, false);
                string str = sw.ReadLine();
                while (str != null)
                {
                    var res = Conv(str);
                    canvas.Add(res);
                    str = sw.ReadLine();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (sw != null)
                {
                    sw.Close();
                }
            }
        }

        private Figure Conv(string str)
        {
            string[] ss = str.Split(" ");
            Figure newFigure = null;
            switch (ss[0])
            {
                case "Line":
                    newFigure = new Line(int.Parse(ss[1]), int.Parse(ss[2]),
                        int.Parse(ss[3]), int.Parse(ss[4]), int.Parse(ss[5]), ss[6]);
                    break;
                case "Triangle":
                    newFigure = new Triangle(int.Parse(ss[1]), int.Parse(ss[2]),
            int.Parse(ss[3]), int.Parse(ss[4]), int.Parse(ss[5]), int.Parse(ss[6]), int.Parse(ss[7]), ss[8]);
                    break;
                case "Rectangle":
                    newFigure = new Rectangle(int.Parse(ss[1]), int.Parse(ss[2]),
          int.Parse(ss[3]), int.Parse(ss[4]), int.Parse(ss[5]), ss[6]);
                    break;
                case "Circle":
                    newFigure = new Circle(int.Parse(ss[1]), int.Parse(ss[2]),
                        int.Parse(ss[3]), int.Parse(ss[4]), int.Parse(ss[5]), ss[6]);

                    break;
            }
            return newFigure;
        }
    }
}
