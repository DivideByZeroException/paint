﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace paint
{
    class Triangle : Figure
    {
        public PointFig A
        {
            get { return basePointFig; }
            set { basePointFig = value; }
        }

        public PointFig B;
        public PointFig C;
        

        public Triangle(PointFig a, PointFig b, PointFig c) : base(a)
        {
            B = b;
            C = c;
        }

        public Triangle(int x1, int y1, int x2, int y2, int x3, int y3, int thick, string col) : base(x1,y1)
        {


            B = new PointFig(x2, y2);
            C = new PointFig(x3, y3);
            thick_size = thick;
            fcolor = col;
        }

        public override void Draw(Graphics paper)
        {
            paper.DrawPolygon(new Pen(Color.FromArgb(int.Parse(fcolor)), thick_size), new Point[] {new Point(A.X,A.Y), new Point(B.X, B.Y) , new Point(C.X, C.Y) });
           
        }

        public override string ToString()
        {
            return $"Triangle {A.X} {A.Y} {B.X} {B.Y} {C.X} {C.Y} {thick_size} {fcolor}\n";
        }
    }
}
